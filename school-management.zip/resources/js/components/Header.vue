<template>
  <Topbar />
</template>

<script setup>
import Topbar from './Topbar.vue'
</script>
